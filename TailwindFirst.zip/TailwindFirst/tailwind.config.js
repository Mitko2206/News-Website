/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.{html,js,php,ts}"],
  theme: {
    extend: {
    },
  },
  plugins: [],
}

